function out = square(x)

out = x.^2;

end