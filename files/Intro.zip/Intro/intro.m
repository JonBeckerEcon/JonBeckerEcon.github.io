%% CM_Lecture2_all_code_demo.m
% Computational Methods Lecture 2: Getting Started With MATLAB
% This script includes every single line of MATLAB code shown in the slide deck.

%% ------------------------------------------------------------------------
% Numbers and Variables
%% ------------------------------------------------------------------------
disp('--- Numbers and Variables ---');

2 + 4 % You can use MATLAB as a calculator. This line yields ans = 6

x = 7 % From now on, whenever you type x that is the as typing 7
x * 2 % This line returns ans = 14
x = 8 % This line overwrites x. Now typing x is typing 8
y = 5 * 3 % Variables can be the result of operations
z = 2 * x % These operations can involve previosuly assigned variables
x = 2 * x % Variables can be overwritten self-referentially
x = x + 1; % A semicolon surpresses printing. The workspace is updated, though

%% ------------------------------------------------------------------------
% Common Mathematical Functions
%% ------------------------------------------------------------------------
disp('--- Common Mathematical Functions ---');

x = 2;

exp(x) % e^x
log(x) % Natural log
sin(x) % Sine of x
cos(x) % Cosine

sqrt(x) % Square root
abs(-3) % Absolute value = 3

y = [1, 4, 9];
sqrt(y) % Functions apply elementwise to vectors/matrices

%% ------------------------------------------------------------------------
% Starting a Script (housekeeping)
%% ------------------------------------------------------------------------
disp('--- Starting a Script (housekeeping) ---');

clear all
close all
clc

x = 7
x = x^2

%% ------------------------------------------------------------------------
% Vectors and Matrices + Indexing
%% ------------------------------------------------------------------------
disp('--- Vectors and Matrices + Indexing ---');

vc = [10; 20; 30; 40] % Separating numbers by ; generates a column vector
vr = [10, 20, 30, 40] % Separating numbers by , generates a row vector
v = vr' % ' transposes a vector such that v = vc
A = [1, 2; 3, 4] % This stores a matrix with rows [1, 2] and [3, 4]

v(1) % This selects the first entry from v
v(2:3) % This selects the second and third entry from v
v(end) % This selects the last entry from v
v(end - 1) % This selects the second-to-last entry from v

A(1,2) % This selects the first row, second column entry of A
A(:,1) % This selects the entire first column of A
A(2,:) % This selects the entire second row of A
b = A(2,2) % This assigns the (2,2) entry of A to b

%% ------------------------------------------------------------------------
% Creating Vectors
%% ------------------------------------------------------------------------
disp('--- Creating Vectors ---');

v1 = [1; 2; 3; 4]; % Column vector typed entry-by-entry
v2 = [1, 2, 3, 4]; % Row vector typed entry-by-entry

v3 = 1:4; % Row vector [1, 2, 3, 4]
v4 = 0:0.5:2; % Start:step:end [0, 0.5, 1.0, 1.5, 2.0]

v5 = linspace(0,1,5); % 5 evenly spaced points between 0 and 1

%% ------------------------------------------------------------------------
% Basic Vector Operations + Summaries
%% ------------------------------------------------------------------------
disp('--- Basic Vector Operations ---');

x = [1; 2; 3];
y = [4; 5; 6];

x + y % Vector addition
x - y % Vector subtraction
3 * x % Scalar multiplication

sum(x)  % sum
mean(x) % mean
max(x)  % max
min(x)  % min

size(x);

%% ------------------------------------------------------------------------
% Vector Norms and Dot Products
%% ------------------------------------------------------------------------
disp('--- Vector Norms and Dot Products ---');

x = [1; 2; 3];
y = [4; 5; 6];

dot_xy = x' * y % Dot product via matrix multiply
dot_xy = dot(x, y); % Built-in dot product (same result)

nx = norm(x) % Euclidean norm
ny = norm(y) % Euclidean norm

%% ------------------------------------------------------------------------
% Building and Inspecting Matrices
%% ------------------------------------------------------------------------
disp('--- Building and Inspecting Matrices ---');

A = [1, 2; 3, 4]; % 2-by-2 matrix
B = [5, 6; 7, 8]; % Another 2-by-2 matrix

size(A) % Returns [2 2]

I = eye(3);   % 3-by-3 identity matrix
Z = zeros(2,3); % 2-by-3 matrix of zeros
O = ones(2,3);  % 2-by-3 matrix of ones

%% ------------------------------------------------------------------------
% Matrix Algebra
%% ------------------------------------------------------------------------
disp('--- Matrix Algebra ---');

A = [1, 2; 3, 4];
B = [5, 6; 7, 8];

A + B % Entrywise addition
2 * A % Scalar times matrix

C = A * B % Matrix product
D = B * A % Different product

%% ------------------------------------------------------------------------
% More Matrix Operations
%% ------------------------------------------------------------------------
disp('--- More Matrix Operations ---');

A = [1, 2, 3; 4, 5, 6];

sum(A)    % Column sums
sum(A,2)  % Row sums

mean(A)   % Column means
mean(A, 2) % Row means
A'        % Transpose

d = diag(A); % Take main diagonal as a column vector
D = diag(d); % Put d on the diagonal of a square matrix

%% ------------------------------------------------------------------------
% Elementwise vs Matrix Operations
%% ------------------------------------------------------------------------
disp('--- Elementwise vs Matrix Operations ---');

x = [1; 2; 3];

x.^2   % Squares each entry
x .* x % Same as x.^2

x * x' % Outer product
x' * x % Dot product scalar

%% ------------------------------------------------------------------------
% Logical Expressions
%% ------------------------------------------------------------------------
disp('--- Logical Expressions ---');

x = 3;
y = 5;

x > 2
x < 2
x == 3
x ~= y

(x > 1) && (y < 10)
(x < 1) || (y < 10)

all(x > 0)
any(x > 0)

%% ------------------------------------------------------------------------
% If Statements
%% ------------------------------------------------------------------------
disp('--- If Statement ---');

x = 3;

if x > 2
    y = 10;
else
    y = -10;
end % returns y = 10

%% ------------------------------------------------------------------------
% For Loops
%% ------------------------------------------------------------------------
disp('--- For Loops ---');

s = 0;
for k = 1:5
    s = s + k;
end % returns s = 15

x = [10; 20; 30; 40];
n = length(x);
for i = 1:n
    y(i) = 2 * x(i);
end

% Vectorized equivalent
y = 2 * x;

%% ------------------------------------------------------------------------
% While Loops
%% ------------------------------------------------------------------------
disp('--- While Loops ---');

x = 1;
while x < 100
    x = 2 * x;
end % returns first value >= 100

x = 1;
diff = 1;
tol = 1e-6;
while diff > tol
    x_new = 0.5 * (x + 2/x); % Example update
    diff = abs(x_new - x);
    x = x_new;
end

%% ------------------------------------------------------------------------
% Function Handles
%% ------------------------------------------------------------------------
disp('--- Function Handles ---');

f = @(x) x.^2; % Anonymous function: f(x) = x^2
f(2) % Returns scalar ans = 4
f([-2, -1, 0, 1, 2]) % Returns vector ans = [4, 1, 0, 1, 4]

alpha = 0.3; % Capital elasticity of output
f = @(k) k.^alpha; % DRS production function
f(4)
f([1, 2, 3, 4])

%% ------------------------------------------------------------------------
% Function Files: square.m
%% ------------------------------------------------------------------------
disp('--- Function File: square.m ---');
% Requires square.m in the same folder
square(3) % Returns scalar ans = 9
square([-2, 0, 2]) % Returns vector ans = [4, 0 , 4]

%% ------------------------------------------------------------------------
% Functions With Multiple Outputs
%% ------------------------------------------------------------------------
disp('--- Multiple Outputs ---');

[u, mu] = utility(3, 2); % Capture both outputs

u = utility(3, 2);

%% ------------------------------------------------------------------------
% Scripts Calling Functions (production.m + utility.m)
%% ------------------------------------------------------------------------
disp('--- Scripts Calling Functions ---');

clear all; close all; clc;

% Parameters
alpha = 0.36;
gamma = 2;

% Grid
k = linspace(0.1, 5, 100)';

% Computations
y = production(k, alpha);
u = utility(y, gamma);

% Plot
figure;
plot(k, u)

%% ------------------------------------------------------------------------
% Basic Plots
%% ------------------------------------------------------------------------
disp('--- Basic Plots ---');

x = 0:0.1:10;
y = sin(x);

figure; % Open a new figure window
plot(x, y); % Simple line plot

title('Sine function');
xlabel('x');
ylabel('sin(x)');

%% ------------------------------------------------------------------------
% Multiple Lines
%% ------------------------------------------------------------------------
disp('--- Multiple Lines ---');

x = 0:0.1:10;
y1 = sin(x);
y2 = cos(x);

figure;
hold on; % Layering multiple plots
plot(x, y1, '-'); % Solid line
plot(x, y2, '--'); % Dashed line
grid on; % Add grid lines
legend('sin(x)', 'cos(x)', ...
    'Location', 'best');
xlabel('x');
ylabel('Value');
title('Sine and Cosine');
hold off;

%% ------------------------------------------------------------------------
% Alice and Bob: Cobb-Douglas Economy
%% Step 1: Parameters and Utility Code
%% ------------------------------------------------------------------------
disp('--- Alice and Bob: Step 1 ---');

clear all; close all; clc

xbar_A = 2; % Alice’s endowment of apples
xbar_B = 4; % Bob’s endowment of apples

ybar_A = 5; % Alice’s endowment of potatoes
ybar_B = 3; % Bob’s endowment of potatoes

alpha_A = 1/2; % Alice’s preference for apples
alpha_B = 1/3; % Bob’s preference for apples

px = 1; % Prices (apples are numeraire, py is endogenous)

u = @(x,y,alpha) alpha.*log(x) + (1-alpha).*log(y); % Utility
mu_x = @(x,y,alpha) alpha./x; % Marginal utility apples
mu_y = @(x,y,alpha) (1-alpha)./y; % Marginal utility potatoes

%% ------------------------------------------------------------------------
% Let’s Plot Some Utilities
%% ------------------------------------------------------------------------
disp('--- Plot Utilities/MUs ---');

x_grid = linspace(0,4,1000); % Grid for apples from 0 to 4
y_grid = linspace(0,4,1000); % Grid for potatoes from 0 to 4

xgrid = x_grid;
ygrid = y_grid;

figure; hold on;

plot(xgrid,u(x_grid,1,alpha_A)) % Alice’s utility from 0 to 4 apples at 1 potato
plot(ygrid,u(2,y_grid,alpha_A)) % Alice’s utility from 0 to 4 pototoes at 2 apples
plot(ygrid,u(2,y_grid,alpha_B)) % Bob’s utility from 0 to 4 pototoes at 2 apples

figure; hold on;

plot(xgrid,mu_x(x_grid,1,alpha_A)) % Alice’s mu from 0 to 4 apples at 1 potato
plot(xgrid,mu_y(x_grid,1,alpha_A)) % Alice’s mu from 0 to 4 apples at 1 potato

%% ------------------------------------------------------------------------
% Step 2: MRS and Willingness to Trade
%% ------------------------------------------------------------------------
disp('--- Step 2: MRS ---');

% MRS as a function of apples, potatoes, and preference parameters
mrs_xy = @(x,y,alpha) mu_x(x,y,alpha)./mu_y(x,y,alpha);

% Alice’s MRS at her endowment
mrs_A = mrs_xy(xbar_A,ybar_A,alpha_A)

% Bob’s MRS at his endowment
mrs_B = mrs_xy(xbar_B,ybar_B,alpha_B)

%% ------------------------------------------------------------------------
% Step 3: Individual Demand
%% ------------------------------------------------------------------------
disp('--- Step 3: Individual Demand ---');

mA = @(py) xbar_A + py.*ybar_A; % Alice’s budget as a function of potato price
mB = @(py) xbar_B + py.*ybar_B; % Bob’s budget as a function of potato price

% Individual potato demands
y_demand = @(py,alpha,xbar,ybar) (1-alpha).*(xbar + py.*ybar)./py;

yA = @(py) y_demand(py,alpha_A,xbar_A,ybar_A); % Alice’s demand as a function of py
yB = @(py) y_demand(py,alpha_B,xbar_B,ybar_B); % Bob’s demand as a function of py

%% ------------------------------------------------------------------------
% Step 4: Aggregate (Excess) Demand
%% ------------------------------------------------------------------------
disp('--- Step 4: Excess Demand ---');

Ybar = ybar_A + ybar_B;

agg_y = @(py) yA(py) + yB(py); % Aggregate demand
excess = @(py) agg_y(py) - Ybar; % Excess demand in potatoes

%% ------------------------------------------------------------------------
% Step 5: Plot and Equilibrium Price
%% ------------------------------------------------------------------------
disp('--- Step 5: Equilibrium via fzero ---');

py_grid = linspace(0.1,5,500);

figure;
plot(py_grid, excess(py_grid));
yline(0);
xlabel('p_y'); ylabel('Excess demand for y');
title('Excess demand in Cobb-Douglas economy');

% This is an numeric root finder, we will spend some time on this
py_star = fzero(excess,1); % 1 is an initial guess

% Equilibrium allocations
yA_star = yA(py_star);
yB_star = yB(py_star);

%% ------------------------------------------------------------------------
% CES Preferences
%% CES Step 1: Parameters and Utility in Code
%% ------------------------------------------------------------------------
disp('--- CES Step 1 ---');

sigma_A = 0.8; % Alice’s elasticity of substitution
sigma_B = 1.2; % Bob’s elasticity of substitution

% Example: CES utility for Alice
ces_u_A = @(x,y) ( alpha_A^(1/sigma_A).*x.^((sigma_A-1)/sigma_A) ...
    + (1-alpha_A)^(1/sigma_A).*y.^((sigma_A-1)/sigma_A) ) ...
    .^(sigma_A/(sigma_A-1));

%% ------------------------------------------------------------------------
% CES Step 3: Individual and Aggregate Demand
%% ------------------------------------------------------------------------
disp('--- CES Demand + Excess Demand ---');

% CES share of expenditure on potatoes
ces_share_y = @(py,alpha,sig) ...
    ( (1-alpha).^sig .* py.^(1-sig) ) ./ ...
    ( alpha.^sig .* 1.^(1-sig) + (1-alpha).^sig .* py.^(1-sig) );

% CES potato demand for one agent
ces_y_demand = @(py,alpha,sig,xbar,ybar) ...
    ces_share_y(py,alpha,sig) .* (xbar + py.*ybar)./py;

% Alice and Bob
yA_ces = @(py) ces_y_demand(py,alpha_A,sigma_A,xbar_A,ybar_A);
yB_ces = @(py) ces_y_demand(py,alpha_B,sigma_B,xbar_B,ybar_B);

% Aggregate CES demand and excess demand
agg_y_ces = @(py) yA_ces(py) + yB_ces(py);
excess_ces = @(py) agg_y_ces(py) - Ybar;

%% ------------------------------------------------------------------------
% CES Step 4: Equilibrium Price via Root-Finding
%% ------------------------------------------------------------------------
disp('--- CES Equilibrium ---');

py_grid = linspace(0.1,5,500);

figure;
plot(py_grid, excess_ces(py_grid));
yline(0);
xlabel('p_y'); ylabel('Excess demand for y (CES)');
title('Excess demand under CES preferences');

% Numerical equilibrium price under CES
py_star_ces = fzero(excess_ces,1); % initial guess at 1

% Equilibrium CES allocations
yA_star_ces = yA_ces(py_star_ces);
yB_star_ces = yB_ces(py_star_ces);

disp('--- Done. ---');
