function [u, mu] = utility(x, gamma)

u  = x.^(1 - gamma)/(1 - gamma);

mu = x.^(-gamma);

end