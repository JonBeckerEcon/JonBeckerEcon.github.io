function y = production(x, alpha)

y = x.^alpha;

end